define({
  "name": "PsychologyAPIs",
  "version": "1.0.0",
  "description": "心理测评接口文档",
  "title": "PsychologyAPIs",
  "url": "http://www.psychology.akirayu.cn",
  "sampleUrl": false,
  "defaultVersion": "0.0.0",
  "apidoc": "0.3.0",
  "generator": {
    "name": "apidoc",
    "time": "2020-06-16T03:15:52.959Z",
    "url": "http://apidocjs.com",
    "version": "0.22.1"
  }
});
